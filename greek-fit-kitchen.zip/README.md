# Greek Fit Kitchen — Next-Level Healthy Meal Preparation Platform

> **"BIG GREEK FLAVOUR. ZERO MEAL PREP."**  
> Managed by **George the Greek** (3575 Lake Shore Blvd W, Etobicoke, ON M8W 1P5)  
> Powered by **Lean Meal** ([leanmeal.ca](https://leanmeal.ca))  
> Designed & Developed by **Penta Services** ([pentaservices.co.uk](https://pentaservices.co.uk))

---

## 🏛️ Executive Summary

Greek Fit Kitchen is a comprehensive, production-quality online ordering platform, customer e-commerce experience, business administration dashboard, and touchscreen kitchen display tablet purpose-built for scheduled meal-prep delivery services across Toronto and the Greater Toronto Area.

Built strictly according to official brand guidelines and flyer specifications, the platform combines the navy-and-yellow brand palette with high-contrast typography, interactive meal builders, and real-time order synchronization.

---

## 📦 Key Deliverables Included

1. **Customer-Facing Web Application (`index.html`)**:
   - Hero Section with high-resolution food photography slider and brand badges.
   - Promotional Banner: 6-meal plan starting from **$59.94 CAD**, **10% OFF** orders of 7+ meals.
   - Complete Menu with all 20 flyer dishes, category tabs, and search bar.
   - Interactive Meal Plan Builder with live progress gauge (e.g. *4 of 6 meals selected*).
   - Side customizer with 2 included sides from 11 gourmet options (Pasta al Greco exception enforced).
   - Distance rate calculator: **$5.99 base + $0.99 per kilometre** from George the Greek.
   - Free store pickup option at 3575 Lake Shore Blvd W, Etobicoke.
   - Advance scheduled delivery for **Sunday** (cutoff: Friday 12:00 PM Toronto time) and **Wednesday** (cutoff: Monday 12:00 PM Toronto time).
   - Stripe-compatible test checkout with 1-click test card filler.
   - Order confirmation modal with detailed invoice breakdown.
   - Customer account portal with order history and 1-click reordering.
   - Catering request and special dietary request modals.
   - Privacy, Terms & Conditions, and Refund Policy modals.

2. **Business Administration Console (`admin.html`)**:
   - Live revenue metrics, order funnels, Sunday/Wednesday batch tallies.
   - Menu & Pricing editor to adjust dish names, prices, categories, and stock availability.
   - Orders Manager with status transitions, refund processing, and kitchen slip printing.
   - Delivery & Cutoff engine settings ($5.99 base, $0.99/km, cutoffs, pickup address).
   - Promotional rules editor (6-meal minimum, 10% volume discount rate).
   - Tax engine settings (Ontario HST 13%).
   - CSV order report exporter.

3. **Touchscreen Kitchen Display Tablet (`kitchen.html`)**:
   - High-contrast Kanban board: *1. New Orders*, *2. In Prep*, *3. Ready (Packed)*, *4. Dispatched*.
   - Filter by delivery batch (*All*, *Sunday Batch*, *Wednesday Batch*).
   - Itemized plate breakdowns with exact side 1, side 2, extra sides, and chef notes.
   - One-tap ticket status advancement.
   - Thermal printer kitchen ticket slip generator.
   - Multi-window storage synchronization with the customer storefront.

4. **Automated Test Suite (`test-business-rules.js`)**:
   - 48 automated tests validating flyer dishes, approved prices, sides, 6-meal minimum, 10% discount, distance formulas, pickup address, theme switcher, and Penta Services footer credit bar.

5. **WordPress Theme Package (`wordpress-theme/greek-fit-kitchen.zip`)**:
   - Ready-to-deploy standalone WordPress theme package with dynamic templates, hooks, and assets.

---

## 🧪 Running the Automated Verification Tests

Ensure Node.js is installed, then run:

```bash
node test-business-rules.js
```

All 48 tests will execute synchronously to verify business compliance.

---

## 🎨 Mandatory Requirements Compliance

* **Theme Switcher (Rule 1)**: Header includes a circular button displaying a Crescent Moon icon in Light mode (to switch to Dark) and a Sun icon in Dark mode (to switch to Light), with persistence in `localStorage`.
* **Penta Services Credit Bar (Rule 2)**: Located at the absolute bottom of the footer across all views, featuring the official SVG badge and tracking links to `pentaservices.co.uk`.
